#File content

NODE_MAIN_CONTENT = "#TODO main python file content"
CONFIG_CONTENT = "#"
