class StructMaster(object):
    pass