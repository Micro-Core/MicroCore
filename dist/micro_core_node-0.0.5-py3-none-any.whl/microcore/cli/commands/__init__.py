__DEFAULT_NAME = "node_1"
__DEFAULT_PATH = "."



